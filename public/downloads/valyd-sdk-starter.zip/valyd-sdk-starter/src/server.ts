import express from "express";
import cookieParser from "cookie-parser";
import { ValydClient } from "valyd-idp-sdk";

import { config } from "./config.js";
import { sessions } from "./sessions.js";
import { homePage } from "./views/home.js";
import { errorPage } from "./views/error.js";

const valyd = new ValydClient({
  clientId: config.valyd.clientId,
  clientSecret: config.valyd.clientSecret,
  redirectUri: config.valyd.redirectUri,
  baseUrl: config.valyd.baseUrl,
});

const app = express();
app.use(cookieParser());
app.use(express.urlencoded({ extended: false }));
app.use(express.static("public"));

/* -------------------------- Home -------------------------- */
app.get("/", (req, res) => {
  const session = sessions.get(req.cookies[config.appSessionCookie.name]);
  res.type("html").send(homePage(session));
});

/* ----------------------- Login start ---------------------- */
// 1. createLoginSession()  → 2. store marker  → 3. redirect to Valyd
app.get("/login", async (_req, res, next) => {
  try {
    const session = await valyd.createLoginSession();

    res.cookie(config.loginCookie.name, session.marker, {
      httpOnly: true,
      sameSite: "lax",
      secure: config.isProd,
      maxAge: config.loginCookie.maxAgeMs,
      path: "/",
    });

    const url = valyd.getAuthorizationUrl({
      state: session.authorizeState,
      scope: config.scopes,
      productName: config.productName,
    });

    res.redirect(url);
  } catch (err) {
    next(err);
  }
});

/* -------------------------- Callback ---------------------- */
// 4. parseCallback  → 5. verifyLoginSession  → 6. exchangeCode  → 7. userinfo
app.get("/callback", async (req, res) => {
  const { code, error, errorDescription } = valyd.parseCallback(req.originalUrl);

  if (error) {
    return res.status(400).type("html").send(
      errorPage("Valyd returned an error", errorDescription || error, { error, errorDescription }),
    );
  }
  if (!code) {
    return res.status(400).type("html").send(errorPage("Missing code", "No authorization code on the callback."));
  }

  // CSRF — verify the marker we set on the way out. NEVER compare callback state to anything.
  const marker = req.cookies[config.loginCookie.name];
  const { valid } = await valyd.verifyLoginSession(marker);
  if (!valid) {
    return res.status(400).type("html").send(
      errorPage(
        "Invalid login session",
        "The login marker is missing, expired, or tampered with. Start the login flow again from /.",
      ),
    );
  }

  try {
    // Exchange the one-time code for tokens (server-side).
    const tokens = await valyd.exchangeCode(code);

    // Fetch user data using the access token.
    const user = await valyd.getUserInfo(tokens.accessToken);
    let verifications: unknown;
    if (config.scopes.includes("verifications")) {
      try {
        verifications = await valyd.getVerifications(tokens.accessToken);
      } catch {
        // Scope might not be enabled for this client. Soft-fail.
        verifications = { note: "verifications scope not enabled or call failed" };
      }
    }

    const appSession = sessions.create({
      user,
      verifications,
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken,
    });

    // Clear the login marker; set the app session cookie.
    res.clearCookie(config.loginCookie.name, { path: "/" });
    res.cookie(config.appSessionCookie.name, appSession.id, {
      httpOnly: true,
      sameSite: "lax",
      secure: config.isProd,
      maxAge: config.appSessionCookie.maxAgeMs,
      path: "/",
    });

    res.redirect("/");
  } catch (err: any) {
    res.status(500).type("html").send(
      errorPage("Token exchange failed", err?.message || String(err), {
        code: err?.code,
        status: err?.status,
        message: err?.message,
      }),
    );
  }
});

/* -------------------------- Logout ------------------------ */
app.post("/logout", (req, res) => {
  sessions.destroy(req.cookies[config.appSessionCookie.name]);
  res.clearCookie(config.appSessionCookie.name, { path: "/" });
  res.clearCookie(config.loginCookie.name, { path: "/" });
  res.redirect("/");
});

/* ----------------------- Error handler -------------------- */
app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error(err);
  res.status(500).type("html").send(errorPage("Server error", err?.message || "Unknown error"));
});

app.listen(config.port, () => {
  console.log(`\n✓ Valyd SDK starter running\n  → http://localhost:${config.port}\n  Redirect URI: ${config.valyd.redirectUri}\n  IdP:          ${config.valyd.baseUrl}\n`);
});
