// Tiny in-memory session store. NOT for production — swap for Redis/DB.
import { randomUUID } from "node:crypto";

export interface AppSession {
  id: string;
  user: unknown;
  verifications?: unknown;
  accessToken: string;
  refreshToken?: string;
  createdAt: number;
}

const store = new Map<string, AppSession>();

export const sessions = {
  create(data: Omit<AppSession, "id" | "createdAt">): AppSession {
    const session: AppSession = { id: randomUUID(), createdAt: Date.now(), ...data };
    store.set(session.id, session);
    return session;
  },
  get(id: string | undefined): AppSession | undefined {
    if (!id) return undefined;
    return store.get(id);
  },
  destroy(id: string | undefined) {
    if (id) store.delete(id);
  },
};
