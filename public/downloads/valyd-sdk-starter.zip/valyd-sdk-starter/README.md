# Valyd SDK Starter

A minimal Express app that demonstrates the full **Valyd TPSSO/OAuth2** flow using
[`valyd-idp-sdk@^0.2.0`](https://www.npmjs.com/package/valyd-idp-sdk) — including
**login-session CSRF protection** (`createLoginSession` / `verifyLoginSession`).

## Why login sessions?

Valyd does **not** echo the OAuth `state` you send. The `state` you receive on the
callback is Valyd's own session id. The classic `if (sentState !== callbackState)`
check therefore **fails** for TPSSO. The SDK ships purpose-built helpers instead.

## Run it

```bash
# 1. Install
npm install

# 2. Configure
cp .env.example .env
# → fill in VALYD_CLIENT_ID, VALYD_CLIENT_SECRET, VALYD_REDIRECT_URI

# 3. Start
npm run dev
# → http://localhost:8080
```

In the Valyd dev portal, register a redirect URI matching `VALYD_REDIRECT_URI`
(default: `http://localhost:8080/callback`) and enable the scopes you want
(default: `profile verifications`).

## What's wired up

| Route             | What it does                                                            |
| ----------------- | ----------------------------------------------------------------------- |
| `GET  /`          | Home — login button, or signed-in profile card                          |
| `GET  /login`     | `createLoginSession()` → cookie → `getAuthorizationUrl()` → redirect   |
| `GET  /callback`  | `parseCallback()` → `verifyLoginSession()` → `exchangeCode()` → user   |
| `POST /logout`    | Destroys the in-memory app session and cookies                          |

To repoint at a different Valyd environment, edit `src/config.ts` (or set
`VALYD_BASE_URL` in `.env`). No other file changes required.

## Layout

```
src/
  config.ts        — single place for env config
  server.ts        — Express routes + SDK calls
  sessions.ts      — tiny in-memory app session store (swap for Redis in prod)
  views/           — server-rendered HTML
public/styles.css  — styling
.env.example
```

## Production checklist

- Replace `sessions.ts` with Redis / your DB session store.
- Set `NODE_ENV=production` so cookies are issued with `Secure`.
- Serve over HTTPS.
- Never expose `VALYD_CLIENT_SECRET` or login markers to the browser JS.
